/**
 * ============================================================
 * WEARAUTO.JS - Mock Handler for equip.wearAuto
 * ============================================================
 * 
 * Purpose: Auto-equip best available equipment onto a hero
 * Replaces current equips with optimal ones from inventory
 * Returns updated hero total attributes and equip state
 * 
 * HAR Reference: s398-zd.pksilo.com_2026_04_01_22_14_53.har
 * HAR Count: 7 entries (uncompressed)
 * 
 * HAR Request fields:
 *   type, action, userId, heroId, equipInfo:{slot:equipId},
 *   weaponId, version
 * 
 * HAR Response fields (11 top-level):
 *   type, action, userId, heroId, equipInfo, weaponId, version,
 *   _totalAttr:{_items:{0-41}}, _changeInfo:{_items:{equipId:num}},
 *   _equipItem:{_suitItems[], _earrings{}, _suitAttrs[],
 *               _equipAttrs[], _weaponState},
 *   _linkHeroesTotalAttr:{}, _oldWeaponId?
 *   _oldWeaponId: hanya ada jika weapon diganti (Hakim: unlink weapon lama)
 * 
 * Client processing (from main.min_777039fc.js):
 *   1. Reads response._totalAttr._items → updates hero total stats & power
 *   2. Reads response._changeInfo._items → updates inventory counts
 *   3. Reads response._equipItem → updates hero's equipped item display
 *      - _suitItems: array of equipped items [{_id, _pos, _version}, ...]
 *      - _earrings: earring state {_id, _level, _attrs, _version}
 *      - _suitAttrs: suit bonus attributes (empty if no set complete)
 *      - _equipAttrs: individual equip stat bonuses [{_id, _num}, ...]
 *      - _weaponState: weapon awakening state (0=normal)
 * 
 * Author: Local SDK Bridge
 * Version: 2.0.0 - fix: || defaults removed, add _oldWeaponId tracking
 * ============================================================
 */

(function(window) {
    'use strict';

    var LOG = {
        prefix: '[EQUIP-WEARAUTO]',
        _log: function(level, icon, message, data) {
            var timestamp = new Date().toISOString().substr(11, 12);
            var styles = {
                success: 'color: #22c55e; font-weight: bold;',
                info: 'color: #6b7280;',
                warn: 'color: #f59e0b; font-weight: bold;',
                error: 'color: #ef4444; font-weight: bold;'
            };
            var style = styles[level] || styles.info;
            var format = '%c' + this.prefix + ' ' + icon + ' [' + timestamp + '] ' + message;
            if (data !== undefined) {
                console.log(format + ' %o', style, data);
            } else {
                console.log(format, style);
            }
        },
        success: function(msg, data) { this._log('success', 'OK', msg, data); },
        info: function(msg, data) { this._log('info', '>>', msg, data); },
        warn: function(msg, data) { this._log('warn', '!!', msg, data); },
        error: function(msg, data) { this._log('error', 'XX', msg, data); }
    };

    // ========================================================
    // CONFIG CACHES
    // ========================================================
    var heroLevelAttrCache = null;
    var heroConfigCache = null;
    var heroTypeParamCache = null;
    var equipCache = null;       // equip.json — equipment stat data
    var heroEquipCache = null;   // heroEquip.json — hero-equip slot mapping

    function loadConfigs() {
        var basePath = window.__GAME_BASE_PATH__ || '';
        var promises = [];

        promises.push(
            fetch(basePath + 'resource/json/hero.json').then(function(r) { return r.json(); })
                .then(function(data) {
                    heroConfigCache = {};
                    var arr = Array.isArray(data) ? data : Object.values(data);
                    arr.forEach(function(h) { heroConfigCache[h.id] = h; });
                    LOG.info('Loaded: hero');
                }).catch(function(e) { LOG.warn('Failed: hero.json — ' + e.message); })
        );

        promises.push(
            fetch(basePath + 'resource/json/heroLevelAttr.json').then(function(r) { return r.json(); })
                .then(function(data) {
                    heroLevelAttrCache = data;
                    LOG.info('Loaded: heroLevelAttr');
                }).catch(function(e) { LOG.warn('Failed: heroLevelAttr — ' + e.message); })
        );

        promises.push(
            fetch(basePath + 'resource/json/heroTypeParam.json').then(function(r) { return r.json(); })
                .then(function(data) {
                    heroTypeParamCache = data;
                    LOG.info('Loaded: heroTypeParam');
                }).catch(function(e) { LOG.warn('Failed: heroTypeParam — ' + e.message); })
        );

        promises.push(
            fetch(basePath + 'resource/json/equip.json').then(function(r) { return r.json(); })
                .then(function(data) {
                    equipCache = {};
                    var arr = Array.isArray(data) ? data : Object.values(data);
                    arr.forEach(function(eq) { equipCache[eq.id] = eq; });
                    LOG.info('Loaded: equip');
                }).catch(function(e) { LOG.warn('Failed: equip.json — ' + e.message); })
        );

        promises.push(
            fetch(basePath + 'resource/json/heroEquip.json').then(function(r) { return r.json(); })
                .then(function(data) {
                    heroEquipCache = data;
                    LOG.info('Loaded: heroEquip');
                }).catch(function(e) { LOG.warn('Failed: heroEquip — ' + e.message); })
        );

        return Promise.all(promises).then(function() {
            LOG.success('All configs loaded');
        });
    }

    // ========================================================
    // ATTRIBUTE CALCULATION
    // ========================================================

    /**
     * Calculate hero total attributes at given level (same as autoLevelUp)
     */
    function calcTotalAttr(displayId, level) {
        var levelData = heroLevelAttrCache ? heroLevelAttrCache[String(level)] : null;
        var heroInfo = heroConfigCache ? heroConfigCache[displayId] : null;
        var typeParam = heroTypeParamCache ? heroTypeParamCache[heroInfo ? heroInfo.heroType : 'strength'] : null;

        var baseHP = 1000, baseATK = 80, baseDEF = 100, spd = 300, talent = 0.3;
        var qualityId = Math.ceil(level / 20);

        if (levelData && heroInfo && typeParam) {
            baseHP  = levelData.hp    * typeParam.hpParam    + (typeParam.hpBais    || 0);
            baseATK = levelData.attack * typeParam.attackParam + (typeParam.attackBais || 0);
            baseDEF = levelData.armor  * typeParam.armorParam  + (typeParam.armorBais || 0);
            spd = heroInfo.speed || 300;
            talent = heroInfo.talent || 0.3;
        }

        var totalHP  = baseHP  * talent;
        var totalATK = baseATK * talent;
        var totalDEF = baseDEF;
        var power = totalHP + totalATK * 11 + totalDEF * 2 + spd * 0.3 + 50;

        var items = {};
        for (var i = 0; i <= 15; i++) {
            var num = 0;
            if (i === 0) num = totalHP;
            else if (i === 1) num = totalATK;
            else if (i === 2) num = totalDEF;
            else if (i === 3) num = spd;
            items[String(i)] = { _id: i, _num: num };
        }

        items['16'] = { _id: 16, _num: 50 };
        items['17'] = { _id: 17, _num: 0 };
        items['18'] = { _id: 18, _num: 0 };
        items['19'] = { _id: 19, _num: 0 };
        items['20'] = { _id: 20, _num: 0 };
        items['21'] = { _id: 21, _num: Math.floor(power) };
        items['22'] = { _id: 22, _num: totalHP };

        for (var j = 23; j <= 41; j++) {
            var num2 = 0;
            if (j === 30) num2 = talent;
            else if (j === 41) num2 = qualityId * 20;
            items[String(j)] = { _id: j, _num: num2 };
        }

        return { _items: items };
    }

    /**
     * Build _equipAttrs from equipped items' stat bonuses
     * Reads equip.json fields: ability1-N, abilityID1-N, value1-N
     * equip.json format per item:
     *   ability1: 'attack', abilityID1: 1, value1: 330
     *   ability2: 'extraArmor', abilityID2: 26, value2: 945
     * Returns [{_id: attrId, _num: value}, ...]
     */
    function buildEquipAttrs(equipInfo) {
        var attrs = {};
        var slots = Object.keys(equipInfo || {});

        for (var s = 0; s < slots.length; s++) {
            var equipId = String(equipInfo[slots[s]]);
            if (!equipId || !equipCache) continue;

            var eq = equipCache[equipId];
            if (!eq) continue;

            // Read ability fields from equip.json (ability1-5, abilityID1-5, value1-5)
            for (var a = 1; a <= 5; a++) {
                var attrId = eq['abilityID' + a];
                var attrVal = eq['value' + a];
                if (attrId !== undefined && attrId !== null && attrVal > 0) {
                    var key = String(attrId);
                    attrs[key] = (attrs[key] || 0) + attrVal;
                }
            }
        }

        var result = [];
        var attrKeys = Object.keys(attrs);
        for (var i = 0; i < attrKeys.length; i++) {
            var id = parseInt(attrKeys[i]);
            var val = attrs[attrKeys[i]];
            if (val > 0) {
                result.push({ _id: id, _num: val });
            }
        }

        return result;
    }

    /**
     * Build _suitItems array from equipInfo
     * HAR format: [{_id, _pos, _version}, ...]
     */
    function buildSuitItems(equipInfo) {
        var items = [];
        var slots = Object.keys(equipInfo || {});

        for (var s = 0; s < slots.length; s++) {
            var pos = parseInt(slots[s]);
            var equipId = equipInfo[slots[s]];
            items.push({
                _id: String(equipId),
                _pos: pos,
                _version: '201906201330'
            });
        }

        return items;
    }

    /**
     * Build _changeInfo reflecting equipment swap in inventory
     * New equips consumed (num=0), old equips returned (num=1)
     */
    function buildChangeInfo(newEquipInfo, replacedEquips) {
        var items = {};
        var newSlots = Object.keys(newEquipInfo || {});

        // New equips consumed from inventory
        for (var s = 0; s < newSlots.length; s++) {
            var equipId = newEquipInfo[newSlots[s]];
            if (equipId) {
                items[String(equipId)] = { _id: parseInt(equipId), _num: 0 };
            }
        }

        // Old equips returned to inventory
        var repSlots = Object.keys(replacedEquips || {});
        for (var r = 0; r < repSlots.length; r++) {
            var oldEquipId = String(replacedEquips[repSlots[r]]);
            if (!items[oldEquipId]) {
                items[oldEquipId] = { _id: parseInt(oldEquipId), _num: 1 };
            } else {
                items[oldEquipId]._num = 1;
            }
        }

        return { _items: items };
    }

    // ========================================================
    // MAIN HANDLER
    // ========================================================

    function handleWearAuto(request, playerData) {
        LOG.info('Handling equip.wearAuto');
        LOG.info('heroId: ' + request.heroId);

        var heroId = request.heroId;
        var newEquipInfo = request.equipInfo || {};

        if (!heroId) {
            LOG.error('Missing heroId');
            return {
                ret: 1, type: 'equip', action: 'wearAuto',
                userId: request.userId, version: request.version
            };
        }

        // Get hero data for attribute calculation
        var heros = playerData.heros || {};
        var heroData = heros[heroId];
        var displayId = heroData ? heroData._heroDisplayId : null;
        var heroLevel = 1;

        if (heroData && heroData._heroBaseAttr) {
            heroLevel = heroData._heroBaseAttr._level || 1;
        }

        // --- Merge old + new equips ---
        // Request only contains changed slots; keep existing equips on other slots
        var heroEquips = playerData._heroEquips = playerData._heroEquips || {};
        var oldEquips = heroEquips[heroId] || {};

        // Record old equips being replaced (for _changeInfo)
        var replacedEquips = {};
        var newSlots = Object.keys(newEquipInfo);
        for (var s = 0; s < newSlots.length; s++) {
            var slot = newSlots[s];
            if (oldEquips[slot] && oldEquips[slot] !== newEquipInfo[slot]) {
                replacedEquips[slot] = oldEquips[slot];
            }
        }

        // Merge: new slots overwrite old, other slots keep their equips
        var mergedEquips = {};
        var allSlots = Object.keys(oldEquips).concat(newSlots);
        for (var a = 0; a < allSlots.length; a++) {
            var sl = allSlots[a];
            mergedEquips[sl] = newEquipInfo[sl] !== undefined ? newEquipInfo[sl] : oldEquips[sl];
        }

        // Save merged equips to playerData
        heroEquips[heroId] = mergedEquips;

        LOG.info('displayId=' + displayId + ' level=' + heroLevel);
        LOG.info('equips: ' + JSON.stringify(mergedEquips));

        // --- Weapon tracking (Hakim: _oldWeaponId) ---
        // Hakim code: e._oldWeaponId && (WeaponDataArray[e._oldWeaponId].heroId = "")
        // Artinya: jika weapon diganti, field _oldWeaponId WAJIB ada
        // supaya client unlink weapon lama dari hero
        var heroWeapons = playerData._heroWeapons = playerData._heroWeapons || {};
        var oldWeaponId = heroWeapons[heroId] || null;
        var newWeaponId = request.weaponId;

        // _oldWeaponId hanya ditambahkan ke response jika:
        //   1. hero punya weapon lama, DAN
        //   2. weapon berubah (newWeaponId !== oldWeaponId)
        var weaponChanged = oldWeaponId && newWeaponId && oldWeaponId !== newWeaponId;
        if (newWeaponId && newWeaponId.length > 0) {
            heroWeapons[heroId] = newWeaponId;
        }

        // Build response matching HAR structure (11+1 top-level fields)
        var responseData = {
            type: 'equip',
            action: 'wearAuto',
            userId: request.userId,
            heroId: heroId,
            equipInfo: newEquipInfo,
            weaponId: newWeaponId,
            version: request.version,
            _totalAttr: calcTotalAttr(displayId, heroLevel),
            _changeInfo: buildChangeInfo(newEquipInfo, replacedEquips),
            _equipItem: {
                _suitItems: buildSuitItems(mergedEquips),
                _earrings: {
                    _id: 0,
                    _level: 0,
                    _attrs: { _items: {} },
                    _version: ''
                },
                _suitAttrs: [],
                _equipAttrs: buildEquipAttrs(mergedEquips),
                _weaponState: 0
            },
            _linkHeroesTotalAttr: {}
        };

        // _oldWeaponId: hanya tambahkan jika weapon berubah
        if (weaponChanged) {
            responseData._oldWeaponId = oldWeaponId;
            LOG.info('_oldWeaponId: ' + oldWeaponId + ' → ' + newWeaponId);
        }

        // Apply equip stat bonuses to _totalAttr
        var equipAttrs = responseData._equipItem._equipAttrs;
        for (var e = 0; e < equipAttrs.length; e++) {
            var attrId = String(equipAttrs[e]._id);
            var attrNum = equipAttrs[e]._num;
            if (responseData._totalAttr._items[attrId]) {
                responseData._totalAttr._items[attrId]._num += attrNum;
            }
        }

        // Recalculate power (attr 21) with equip bonuses
        var ta = responseData._totalAttr._items;
        var hp = ta['0']._num;
        var atk = ta['1']._num;
        var def = ta['2']._num;
        var spd = ta['3']._num;
        ta['21']._num = Math.floor(hp + atk * 11 + def * 2 + spd * 0.3 + 50);
        // MaxHP (attr 22) = total HP
        ta['22']._num = hp;

        LOG.success('wearAuto complete. Equips: ' + Object.keys(mergedEquips).length +
                    ' Power=' + ta['21']._num);

        return responseData;
    }

    // ========================================================
    // REGISTER HANDLER
    // ========================================================
    function register() {
        if (typeof window === 'undefined') {
            console.error('[EQUIP-WEARAUTO] window not available');
            return;
        }

        window.MAIN_SERVER_HANDLERS = window.MAIN_SERVER_HANDLERS || {};
        window.MAIN_SERVER_HANDLERS['equip.wearAuto'] = handleWearAuto;

        LOG.success('Handler registered: equip.wearAuto');
        loadConfigs();
    }

    if (typeof window !== 'undefined') {
        register();
    } else {
        var _check = setInterval(function() {
            if (typeof window !== 'undefined') {
                clearInterval(_check);
                register();
            }
        }, 50);
        setTimeout(function() { clearInterval(_check); }, 10000);
    }

})(window);
