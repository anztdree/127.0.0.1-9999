/**
 * ============================================================
 * HEROGETATTRS.JS - Mock Handler for hero.getAttrs
 * ============================================================
 * 
 * Purpose: Returns calculated hero attributes (stats) for requested heroes
 * Called when game needs to display hero stats or during team setup
 * Returns both total attributes (with equipment) and base attributes (raw)
 * 
 * HAR Reference: s398-zd.pksilo.com_2026_04_01_01_08_04.har
 * NOTE: Response is COMPRESSED in real server (decompressFromUTF16)
 *       Our mock returns uncompressed since we don't implement compression
 * 
 * Flow (from game code main.min.js):
 *   1. Game calls: ts.processHandler({type:"hero",action:"getAttrs",
 *      heros:["<heroId>"], userId, version:"1.0"})
 *   2. Response contains _attrs (total stats) and _baseAttrs (raw base stats)
 *   3. Each is an array with 1 element containing _items keyed by attr ID
 * 
 * Attribute IDs (0-41):
 *   0: HP, 1: ATK, 2: DEF, 3: SPD
 *   4-15: Various secondary stats (crit, dodge, counter, etc.)
 *   16: CritRate, 17: CritDmg, 18-22: Other combat stats
 *   21: Power (combat power), 22: MaxHP (for display)
 *   23-41: Resistance stats, control resists, etc.
 *   30: CritDmgRate, 41: Level
 * 
 * HAR Data Structure (decompressed from compressed response):
 *   _attrs: [{_items: {"0":{_id:0,_num:1003.52}, "1":{_id:1,_num:30}, ...}}]
 *   _baseAttrs: [{_items: {"0":{_id:0,_num:3136}, "1":{_id:1,_num:93.75}, ...}}]
 *   Note: _baseAttrs skips keys 16-22 (only has 0-15, 23-41)
 *         _attrs has all keys 0-41
 * 
 * Author: Local SDK Bridge
 * Version: 1.0.0
 * ============================================================
 */

(function(window) {
    'use strict';

    var LOG = {
        prefix: '⚔️ [HERO-ATTRS]',
        _log: function(level, icon, message, data) {
            var timestamp = new Date().toISOString().substr(11, 12);
            var styles = {
                success: 'color: #22c55e; font-weight: bold;',
                info: 'color: #6b7280;',
                warn: 'color: #f59e0b; font-weight: bold;',
                error: 'color: #ef4444; font-weight: bold;'
            };
            var style = styles[level] || styles.info;
            var format = '%c' + this.prefix + ' ' + icon + ' [' + timestamp + '] ' + message;
            if (data !== undefined) {
                console.log(format + ' %o', style, data);
            } else {
                console.log(format, style);
            }
        },
        success: function(msg, data) { this._log('success', '✅', msg, data); },
        info: function(msg, data) { this._log('info', 'ℹ️', msg, data); },
        warn: function(msg, data) { this._log('warn', '⚠️', msg, data); },
        error: function(msg, data) { this._log('error', '❌', msg, data); }
    };

    /**
     * Base stat templates for hero display IDs (from HAR real data)
     * These are the _baseAttrs values (raw stats without equipment)
     * Format: {<attrId>: <value>} — only non-zero values listed
     * 
     * Hero 1205 (Wukong) base stats from HAR at level 3:
     *   HP=3136, ATK=93.75, DEF=153.75, SPD=362, CritDmgRate=0.32, Level=100
     */
    var HERO_BASE_STATS = {
        // Wukong (1205) - starting hero, level 3 base stats
        '1205': {
            0: 3136,    // HP
            1: 93.75,   // ATK
            2: 153.75,  // DEF
            3: 362,     // SPD
            30: 0.32,   // CritDmgRate
            41: 100     // Level cap
        }
    };

    /**
     * Default base stats for unknown heroes (generic stats)
     */
    var DEFAULT_BASE_STATS = {
        0: 1000,    // HP
        1: 80,      // ATK
        2: 100,     // DEF
        3: 300,     // SPD
        30: 0.25,   // CritDmgRate
        41: 100     // Level cap
    };

    /**
     * Build _baseAttrs item structure
     * Key difference from _attrs: _baseAttrs SKIPS keys 16-22
     * Has keys: 0-15, then 23-41
     */
    function buildBaseAttrItem(displayId) {
        var stats = HERO_BASE_STATS[displayId] || DEFAULT_BASE_STATS;
        var items = {};
        
        // Keys 0-15
        for (var i = 0; i <= 15; i++) {
            items[String(i)] = { _id: i, _num: stats[i] || 0 };
        }
        // SKIP 16-22 (HAR behavior: _baseAttrs does not include these)
        // Keys 23-41
        for (var j = 23; j <= 41; j++) {
            items[String(j)] = { _id: j, _num: stats[j] || 0 };
        }
        
        return { _items: items };
    }

    /**
     * Build _attrs item structure (total stats with all bonuses)
     * Has ALL keys 0-41
     * For new player: same as base stats (no equipment bonuses yet)
     * But includes extra fields: 16 (CritRate=50), 21 (Power), 22 (MaxHP display)
     */
    function buildTotalAttrItem(displayId) {
        var baseStats = HERO_BASE_STATS[displayId] || DEFAULT_BASE_STATS;
        var items = {};
        
        // Keys 0-15
        for (var i = 0; i <= 15; i++) {
            items[String(i)] = { _id: i, _num: baseStats[i] || 0 };
        }
        // Keys 16-22 (extra total stats not in baseAttrs)
        items['16'] = { _id: 16, _num: 50 };  // CritRate bonus
        items['17'] = { _id: 17, _num: 0 };
        items['18'] = { _id: 18, _num: 0 };
        items['19'] = { _id: 19, _num: 0 };
        items['20'] = { _id: 20, _num: 0 };
        items['21'] = { _id: 21, _num: Math.floor(baseStats[0] * 0.49 + baseStats[1] * 5) };  // Power (approx)
        items['22'] = { _id: 22, _num: baseStats[0] || 0 };  // MaxHP (same as HP base)
        // Keys 23-41
        for (var j = 23; j <= 41; j++) {
            items[String(j)] = { _id: j, _num: baseStats[j] || 0 };
        }
        
        return { _items: items };
    }

    /**
     * Handler for hero.getAttrs
     * Registered via window.MAIN_SERVER_HANDLERS
     * 
     * Request: {type:"hero", action:"getAttrs", heros:["<heroId>"], userId, version}
     * Response: {type, action, userId, version, _attrs:[...], _baseAttrs:[...]}
     * 
     * For each hero in heros array, returns corresponding attr data
     * For new player with only Wukong (1205), only 1 entry in each array
     */
    function handleHeroGetAttrs(request, playerData) {
        LOG.info('Handling hero.getAttrs');
        LOG.info('UserId: ' + request.userId);

        var heroIds = request.heros || [];
        LOG.info('Requesting attrs for ' + heroIds.length + ' hero(es): ' + JSON.stringify(heroIds));

        // Get player's hero data to find displayId for each heroId
        var heros = playerData.heros || {};
        
        // Build _attrs and _baseAttrs arrays
        var attrs = [];
        var baseAttrs = [];

        for (var i = 0; i < heroIds.length; i++) {
            var heroId = heroIds[i];
            var heroData = heros[heroId];
            
            if (heroData) {
                var displayId = heroData._heroDisplayId || 1205;
                LOG.info('Hero ' + heroId.substring(0, 8) + '... displayId=' + displayId + 
                         ' level=' + (heroData._heroBaseAttr ? heroData._heroBaseAttr._level : '?'));
                
                attrs.push(buildTotalAttrItem(displayId));
                baseAttrs.push(buildBaseAttrItem(displayId));
            } else {
                // Hero not found in player data — use default
                LOG.warn('Hero ' + heroId + ' not found, using default stats');
                attrs.push(buildTotalAttrItem('1205'));
                baseAttrs.push(buildBaseAttrItem('1205'));
            }
        }

        var responseData = {
            type: 'hero',
            action: 'getAttrs',
            userId: request.userId,
            heros: heroIds,
            version: request.version || '1.0',
            _attrs: attrs,
            _baseAttrs: baseAttrs
        };

        LOG.success('getAttrs → ' + attrs.length + ' hero attr(s)');
        // Show key stats for first hero
        if (attrs.length > 0) {
            var firstItems = attrs[0]._items;
            LOG.info('First hero stats: HP=' + firstItems['0']._num + 
                     ' ATK=' + firstItems['1']._num +
                     ' DEF=' + firstItems['2']._num +
                     ' SPD=' + firstItems['3']._num);
        }

        return responseData;
    }

    // ========================================================
    // REGISTER HANDLER
    // ========================================================
    function register() {
        if (typeof window === 'undefined') {
            console.error('[HERO-ATTRS] window not available');
            return;
        }

        window.MAIN_SERVER_HANDLERS = window.MAIN_SERVER_HANDLERS || {};
        window.MAIN_SERVER_HANDLERS['hero.getAttrs'] = handleHeroGetAttrs;

        LOG.success('Handler registered: hero.getAttrs');
    }

    // Auto-register
    if (typeof window !== 'undefined') {
        register();
    } else {
        var _check = setInterval(function() {
            if (typeof window !== 'undefined') {
                clearInterval(_check);
                register();
            }
        }, 50);
        setTimeout(function() { clearInterval(_check); }, 10000);
    }

})(window);
